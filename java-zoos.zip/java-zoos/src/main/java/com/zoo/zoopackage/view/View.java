package com.zoo.zoopackage.view;

public class View
{
    public interface AnimalsOnly
    {
    
    }
}
