package com.zoo.zoopackage.view;

public interface CountZoosWithAnimal
{
    long getAnimalid();
    String getAnimaltype();
    int getCountzoos();
}
